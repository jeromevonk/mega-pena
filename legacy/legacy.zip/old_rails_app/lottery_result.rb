require 'nokogiri'
require 'mechanize'
require 'zip'
require 'csv'

class LotteryResult < ActiveRecord::Base

  URL = "http://www1.caixa.gov.br/loterias/_arquivos/loterias/D_mgsasc.zip"
  INDEXES = [ 0, 1, 2, 3, 4, 5, 6, 7, 9, 12, 13, 14, 15, 16 ]

  def self.download_latest

    m = Mechanize.new
    m.get(URL)

    htm_file = nil

    Zip::InputStream.open(StringIO.new(m.page.body)) do |io|
      while entry = io.get_next_entry
        if entry.name == 'd_megasc.htm'
          htm_file = entry.get_input_stream.read
        else
          # raise "unknown entry in kmz file: #{entry.name}"
        end
      end
    end

    parser = Nokogiri::HTML(htm_file)

    # Not used:
    # - Arrecadacao_Total
    # - Cidade
    # - UF
    # - Acumulado
    # - Valor_Acumulado
    # - Estimativa_Prêmio
    # - Acumulado_Mega_da_Virada

    rows = []

    parser.css('table tr').each do |tr|
      if tr.css('td').count < 5
        next
      end

      row = []
      INDEXES.each do |idx|
        if idx == 12 || idx == 14 || idx == 16
          temp = tr.css('td')[idx].inner_text
          temp.gsub!('.','')
          temp.gsub!(',','.')
          row << temp

        else
          row << tr.css('td')[idx].inner_text
        end
      end

      rows << row
    end

    csv_string = CSV.generate do |csv|
      rows.each do |r|
        csv << r
      end
    end

    record = LotteryResult.create!(text_data: csv_string)
  end
end
