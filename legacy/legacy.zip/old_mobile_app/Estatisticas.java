package com.vonk.admin.loteria;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.TextView;

import java.util.Locale;


public class Estatisticas extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estatisticas);

        TextView tv =(TextView)findViewById(R.id.tvMostraEstatistica);
        String toDisplay = "";

        toDisplay += String.format("Total de concursos: %d\n", + Bilhete.mConcursos.size());

        int iSaiuSena = 0;

        double dMaiorPremioSena = 0;
        double dMenorPremioSena = 10*1000*1000;

        double dMaiorPremioQuina = 0;
        double dMenorPremioQuina = 10*1000*1000;

        double dMaiorPremioQuadra = 0;
        double dMenorPremioQuadra = 10*1000*1000;

        for (int i = 0; i < Bilhete.mConcursos.size(); i++ )
        {
            if ( Bilhete.mConcursos.get(i).getGanhadoresSena() > 0)
                iSaiuSena++;

            if (Bilhete.mConcursos.get(i).getPremioSena() > dMaiorPremioSena)
                dMaiorPremioSena = Bilhete.mConcursos.get(i).getPremioSena();

            if (Bilhete.mConcursos.get(i).getPremioQuina() > dMaiorPremioQuina)
                dMaiorPremioQuina = Bilhete.mConcursos.get(i).getPremioQuina();

            if (Bilhete.mConcursos.get(i).getPremioQuadra() > dMaiorPremioQuadra)
                dMaiorPremioQuadra = Bilhete.mConcursos.get(i).getPremioQuadra();

            if (Bilhete.mConcursos.get(i).getPremioSena() < dMenorPremioSena && Bilhete.mConcursos.get(i).getGanhadoresSena() > 0)
                dMenorPremioSena = Bilhete.mConcursos.get(i).getPremioSena();

            if (Bilhete.mConcursos.get(i).getPremioQuina() < dMenorPremioQuina)
                dMenorPremioQuina = Bilhete.mConcursos.get(i).getPremioQuina();

            if (Bilhete.mConcursos.get(i).getPremioQuadra() < dMenorPremioQuadra)
                dMenorPremioQuadra = Bilhete.mConcursos.get(i).getPremioQuadra();
        }

        // Vezes que saiu a sena
        toDisplay += String.format("Em %d concursos, ou %.2f%%, saiu a sena\n\n", +iSaiuSena, (float)100*iSaiuSena/Bilhete.mConcursos.size() );

        // Maior e menor valor
        toDisplay += String.format(Locale.GERMAN, "Para a sena, o maior valor de rateio foi R$%1$,.2f e o menor foi R$%2$,.2f  \n\n",dMaiorPremioSena, dMenorPremioSena);
        toDisplay += String.format(Locale.GERMAN, "Para a quina, o maior valor de rateio foi R$%1$,.2f e o menor foi R$%2$,.2f  \n\n",dMaiorPremioQuina, dMenorPremioQuina);
        toDisplay += String.format(Locale.GERMAN, "Para a quadra, o maior valor de rateio foi R$%1$,.2f e o menor foi R$%2$,.2f  \n\n",dMaiorPremioQuadra, dMenorPremioQuadra);

        tv.setText(toDisplay);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_estatisticas, menu);
        return true;
    }

}
