package com.vonk.admin.loteria;

import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.vonk.admin.loteria.Resultado;


public class Bilhete extends ActionBarActivity {

    private static final String FILE_NAME = "LoteriaData.csv";
    private static final String TAG = "Loteria_log";
    public static final List<Concurso> mConcursos = new ArrayList<>();

    private static ToggleButton m_aTB[] = new ToggleButton[60];

    // File url to download
    //private static String file_url = "https://dl.dropboxusercontent.com/u/17414083/LoteriaDados.csv";
    private static String file_url = "https://lottery-sena.herokuapp.com/lottery/index";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_bilhete);
        //getSupportActionBar().hide();

        View view = this.findViewById(android.R.id.content);

        {
            m_aTB[0] = (ToggleButton) findViewById(R.id.tb01);
            m_aTB[1] = (ToggleButton) findViewById(R.id.tb02);
            m_aTB[2] = (ToggleButton) findViewById(R.id.tb03);
            m_aTB[3] = (ToggleButton) findViewById(R.id.tb04);
            m_aTB[4] = (ToggleButton) findViewById(R.id.tb05);
            m_aTB[5] = (ToggleButton) findViewById(R.id.tb06);
            m_aTB[6] = (ToggleButton) findViewById(R.id.tb07);
            m_aTB[7] = (ToggleButton) findViewById(R.id.tb08);
            m_aTB[8] = (ToggleButton) findViewById(R.id.tb09);
            m_aTB[9] = (ToggleButton) findViewById(R.id.tb10);
            m_aTB[10] = (ToggleButton) findViewById(R.id.tb11);
            m_aTB[11] = (ToggleButton) findViewById(R.id.tb12);
            m_aTB[12] = (ToggleButton) findViewById(R.id.tb13);
            m_aTB[13] = (ToggleButton) findViewById(R.id.tb14);
            m_aTB[14] = (ToggleButton) findViewById(R.id.tb15);
            m_aTB[15] = (ToggleButton) findViewById(R.id.tb16);
            m_aTB[16] = (ToggleButton) findViewById(R.id.tb17);
            m_aTB[17] = (ToggleButton) findViewById(R.id.tb18);
            m_aTB[18] = (ToggleButton) findViewById(R.id.tb19);
            m_aTB[19] = (ToggleButton) findViewById(R.id.tb20);
            m_aTB[20] = (ToggleButton) findViewById(R.id.tb21);
            m_aTB[21] = (ToggleButton) findViewById(R.id.tb22);
            m_aTB[22] = (ToggleButton) findViewById(R.id.tb23);
            m_aTB[23] = (ToggleButton) findViewById(R.id.tb24);
            m_aTB[24] = (ToggleButton) findViewById(R.id.tb25);
            m_aTB[25] = (ToggleButton) findViewById(R.id.tb26);
            m_aTB[26] = (ToggleButton) findViewById(R.id.tb27);
            m_aTB[27] = (ToggleButton) findViewById(R.id.tb28);
            m_aTB[28] = (ToggleButton) findViewById(R.id.tb29);
            m_aTB[29] = (ToggleButton) findViewById(R.id.tb30);
            m_aTB[30] = (ToggleButton) findViewById(R.id.tb31);
            m_aTB[31] = (ToggleButton) findViewById(R.id.tb32);
            m_aTB[32] = (ToggleButton) findViewById(R.id.tb33);
            m_aTB[33] = (ToggleButton) findViewById(R.id.tb34);
            m_aTB[34] = (ToggleButton) findViewById(R.id.tb35);
            m_aTB[35] = (ToggleButton) findViewById(R.id.tb36);
            m_aTB[36] = (ToggleButton) findViewById(R.id.tb37);
            m_aTB[37] = (ToggleButton) findViewById(R.id.tb38);
            m_aTB[38] = (ToggleButton) findViewById(R.id.tb39);
            m_aTB[39] = (ToggleButton) findViewById(R.id.tb40);
            m_aTB[40] = (ToggleButton) findViewById(R.id.tb41);
            m_aTB[41] = (ToggleButton) findViewById(R.id.tb42);
            m_aTB[42] = (ToggleButton) findViewById(R.id.tb43);
            m_aTB[43] = (ToggleButton) findViewById(R.id.tb44);
            m_aTB[44] = (ToggleButton) findViewById(R.id.tb45);
            m_aTB[45] = (ToggleButton) findViewById(R.id.tb46);
            m_aTB[46] = (ToggleButton) findViewById(R.id.tb47);
            m_aTB[47] = (ToggleButton) findViewById(R.id.tb48);
            m_aTB[48] = (ToggleButton) findViewById(R.id.tb49);
            m_aTB[49] = (ToggleButton) findViewById(R.id.tb50);
            m_aTB[50] = (ToggleButton) findViewById(R.id.tb51);
            m_aTB[51] = (ToggleButton) findViewById(R.id.tb52);
            m_aTB[52] = (ToggleButton) findViewById(R.id.tb53);
            m_aTB[53] = (ToggleButton) findViewById(R.id.tb54);
            m_aTB[54] = (ToggleButton) findViewById(R.id.tb55);
            m_aTB[55] = (ToggleButton) findViewById(R.id.tb56);
            m_aTB[56] = (ToggleButton) findViewById(R.id.tb57);
            m_aTB[57] = (ToggleButton) findViewById(R.id.tb58);
            m_aTB[58] = (ToggleButton) findViewById(R.id.tb59);
            m_aTB[59] = (ToggleButton) findViewById(R.id.tb60);
        }


        // Botao de verificar
        Button btVerificar = (Button) view.findViewById(R.id.btVerificar);
        btVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int iCounter = 0;
                for (int i = 0; i < 60; i++)
                {
                    if ( m_aTB[i].isChecked() )
                    {
                        iCounter++;
                    }
                }

                if ( iCounter == 6 ) 
                {
                    int[] iSelecionados = new int[6];
                    int j = 0;
                    for (byte i = 0; i < 60; i++)
                    {
                        if ( m_aTB[i].isChecked() )
                        {
                            iSelecionados[j] = i+1;
                            j++;
                        }
                    }

                    // Create an intent
                    Intent intent = new Intent(Bilhete.this, Resultado.class);
                    intent.putExtra("Num1", iSelecionados[0] );
                    intent.putExtra("Num2", iSelecionados[1] );
                    intent.putExtra("Num3", iSelecionados[2] );
                    intent.putExtra("Num4", iSelecionados[3] );
                    intent.putExtra("Num5", iSelecionados[4] );
                    intent.putExtra("Num6", iSelecionados[5] );

                    //  Start an Activity using that intent and the request code defined above
                    startActivity(intent);

                }
                else if ( iCounter > 6 ) 
                {
                    Toast.makeText(getApplicationContext(), "Selecione no máximo 6 dezenas", Toast.LENGTH_LONG).show();
                }
                else
                {
                   Toast.makeText(getApplicationContext(), "Selecione ao menos 6 dezenas", Toast.LENGTH_LONG).show();
                }
            }
        });


        // If there is no file at all, download
        long lLocalFileLen = 0;

        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            lLocalFileLen = fis.getChannel().size();
            Log.i(TAG, "Tamanho do arquivo local = " + lLocalFileLen);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if ( lLocalFileLen == 0 )
        {
            Log.i(TAG, "Sem arquivo local ");
            downloadFile();
        }

    }

    @Override
    public void onResume() {
        super.onResume();

        // Load saved Items, if necessary
        if (mConcursos.size() == 0) {
            loadConcursos();
        }

        showNumberOfConcursos();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_bilhete, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_clear)
        {
            for (int i = 0; i < 60; i++)
            {
                m_aTB[i].setChecked(false);
            }

            return true;
        }
        else if (id == R.id.action_atualizar)
        {
            downloadFile();
            return true;
        }
        else if (id == R.id.action_estatisticas)
        {
            // Create an intent
            Intent intent = new Intent(Bilhete.this, Estatisticas.class);

            //  Start an Activity using that intent and the request code defined above
            startActivity(intent);
        }
        else if (id == R.id.action_sobre) {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Bilhete.this);

            // set title
            alertDialogBuilder.setTitle("Sobre");

            // set dialog message
            alertDialogBuilder
                    .setCancelable(false)
                    .setMessage("Desenvolvido por Jerome Vonk (vonkjerome@gmail.com) em parceria com Débora Setton Sanches\n" +
                                "Inspiração: Paula Dondon")
                    .setPositiveButton("Fechar",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int id) {
                        }
                    });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Carrega os concursos ja realizados
    private void loadConcursos() {
        BufferedReader reader = null;
        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            reader = new BufferedReader(new InputStreamReader(fis));

            String line;

            while (null != (line = reader.readLine() ) )
            {
                String[] array_fields = line.split(",");

                // Campo 1 eh o numero do concurso
                int iNumConcurso = Integer.parseInt(array_fields[0]);

                // Campo 2 eh a data do concurso
                Date dataConcurso = Concurso.FORMAT.parse(array_fields[1]);

                // Campos 3,4,5,6,7,8 sao as dezenas
                byte[] byDezenas = new byte[6];
                byDezenas[0] = Byte.valueOf(array_fields[2]);
                byDezenas[1] = Byte.valueOf(array_fields[3]);
                byDezenas[2] = Byte.valueOf(array_fields[4]);
                byDezenas[3] = Byte.valueOf(array_fields[5]);
                byDezenas[4] = Byte.valueOf(array_fields[6]);
                byDezenas[5] = Byte.valueOf(array_fields[7]);

                // Campo 9 é numero de ganhadores sena
                int iNumGanSena = Integer.parseInt(array_fields[8]);

                // Campo 10 é valor premio sena
                double dPremioSena = Double.parseDouble(array_fields[9]);

                // Campo 11 é numero de ganhadores quina
                int iNumGanQuina = Integer.parseInt(array_fields[10]);

                // Campo 12 é valor premio quina
                double dPremioQuina = Double.parseDouble(array_fields[11]);

                // Campo 13 é numero de ganhadores quadra
                int iNumGanQuadra = Integer.parseInt(array_fields[12]);

                // Campo 14 é valor premio quadra
                double dPremioQuadra = Double.parseDouble(array_fields[13]);

                mConcursos.add(new Concurso(iNumConcurso, dataConcurso, byDezenas, iNumGanSena, dPremioSena, iNumGanQuina, dPremioQuina, iNumGanQuadra, dPremioQuadra));
                //Log.i(TAG, "Carregado concurso " + iNumConcurso);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (null != reader) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void unloadConcursos() {
        mConcursos.clear();
    }

    private void showNumberOfConcursos()
    {
        TextView tv = (TextView) findViewById(R.id.tvAtualizado);
        if (mConcursos.size() == 0) {
            tv.setText( "Não há concursos carregados! Aguarde." );
        }
        else
        {
            tv.setText(String.format("%1$d concursos carregados\nÚltimo em %2$te/%2$tm/%2$tY", mConcursos.size(), mConcursos.get(mConcursos.size() - 1).getData()));
        }
    }

    private void showDownloadProgress(int iProgress)
    {
        TextView tv = (TextView) findViewById(R.id.tvAtualizado);
        tv.setText( String.format("Recebido %dk", iProgress ) );
    }

    private void showDownloadStarted()
    {
        TextView tv = (TextView) findViewById(R.id.tvAtualizado);
        tv.setText("Atualizando...");
    }

    private void downloadFile()
    {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
        {
            // fetch data
            Log.i(TAG, "We have internet connection");
            new DownloadFileFromURL().execute(file_url);
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Sem conexão com a internet", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Background Async Task to download file
     * */
    class DownloadFileFromURL extends AsyncTask<String, Integer, String>
    {
        @Override
        protected void onPreExecute() {
            showDownloadStarted();
            super.onPreExecute();
        }

        protected void onProgressUpdate(Integer... progress) {
            showDownloadProgress(progress[0]);
        }

        @Override
        protected void onPostExecute(String string) {
            unloadConcursos();
            loadConcursos();
            showNumberOfConcursos();
        }

        /**
         * Downloading file in background thread
         * */
        @Override
        protected String doInBackground(String... f_url) {
        
            // -------------------------------------------
            // Check the remote file size?
            // --------------------------------------------

            try {
                URL url = new URL(f_url[0]);
                HttpURLConnection conection = (HttpURLConnection) url.openConnection();
                conection.setReadTimeout(10000);
                conection.setConnectTimeout(15000);
                conection.connect();

                long lRemoteFileLen = conection.getContentLength();

                Log.i(TAG, "Tamanho do arquivo remoto= " + lRemoteFileLen);
                //Log.i(TAG, String.format("Tamanho do arquivo = %d", lenghtOfFile));


                // Make the decision:
                // TODO: for the time being, download always
                if ( /*lLocalFileLen == lRemoteFileLen*/ false)
                {
                    Log.i(TAG, "No need to download the file");
                }
                else
                {
                    // Need to download the file
                    Log.i(TAG, "Starting download");
                    InputStream input = new BufferedInputStream(url.openStream(), 8192);
                    FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE);

                    byte data[] = new byte[1024];
                    int count;
                    int iProgress = 0;

                    while ((count = input.read(data)) != -1)
                    {
                        // writing data to file
                        fos.write(data, 0, count);

                        // Show progress
                        iProgress++;
                        if ( iProgress%5 == 0 ) {
                            publishProgress(iProgress);
                        }
                    }

                    // flushing output
                    fos.flush();

                    // closing streams
                    fos.close();
                    input.close();

                    Log.i(TAG, "Download finished");
                }

                // End
                conection.disconnect();
                Log.i(TAG, "Fim, sucesso");

            } catch (Exception e) {
                Log.e("Error: ", e.getMessage());
            }

            return null;
        }
    }


}
