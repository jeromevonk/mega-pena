package com.vonk.admin.loteria;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Concurso {

    public final static SimpleDateFormat FORMAT = new SimpleDateFormat("dd/MM/yyyy", Locale.US);

    private int m_iNumConcurso = 0;
    private Date m_data;
    private byte[] byGlobos = new byte[6];
    private int m_iNumGanSena = 0;
    private int m_iNumGanQuina = 0;
    private int m_iNumGanQuadra = 0;
    private double m_dPremioSena = 0;
    private double m_dPremioQuina = 0;
    private double m_dPremioQuadra = 0;


    Concurso(int iNumConcurso, Date data, byte[] abyGlobos, int iNumGanSenha, double dPremioSena, int iNumGanQuina, double dPremioQuina, int iNumGanQuadra, double dPremioQuadra ) {
        this.m_iNumConcurso = iNumConcurso;
        m_data = data;
        this.byGlobos[0] = abyGlobos[0];
        this.byGlobos[1] = abyGlobos[1];
        this.byGlobos[2] = abyGlobos[2];
        this.byGlobos[3] = abyGlobos[3];
        this.byGlobos[4] = abyGlobos[4];
        this.byGlobos[5] = abyGlobos[5];
        this.m_iNumGanSena  = iNumGanSenha;
        this.m_dPremioSena   = dPremioSena;
        this.m_iNumGanQuina  = iNumGanQuina;
        this.m_dPremioQuina  = dPremioQuina;
        this.m_iNumGanQuadra = iNumGanQuadra;
        this.m_dPremioQuadra = dPremioQuadra;
    }

    public int getNumConcurso() {
        return m_iNumConcurso;
    }

    public byte[] getGlobos() {
        return byGlobos;
    }

    public int getGanhadoresQuadra() {return m_iNumGanQuadra;}

    public int getGanhadoresQuina() {return m_iNumGanQuina;}

    public int getGanhadoresSena() {return m_iNumGanSena;}

    public double getPremioQuadra() {return m_dPremioQuadra;}

    public double getPremioQuina() {return m_dPremioQuina;}

    public double getPremioSena() {return m_dPremioSena;}

    public Date getData() {return m_data;}

}
