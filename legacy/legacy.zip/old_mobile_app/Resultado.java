package com.vonk.admin.loteria;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Locale;


public class Resultado extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        int[] iChosen = new int[6];
        iChosen[0] = getIntent().getExtras().getInt("Num1");
        iChosen[1] = getIntent().getExtras().getInt("Num2");
        iChosen[2] = getIntent().getExtras().getInt("Num3");
        iChosen[3] = getIntent().getExtras().getInt("Num4");
        iChosen[4] = getIntent().getExtras().getInt("Num5");
        iChosen[5] = getIntent().getExtras().getInt("Num6");

        TextView tvBola1 = (TextView) findViewById(R.id.Bola1);
        TextView tvBola2 = (TextView) findViewById(R.id.Bola2);
        TextView tvBola3 = (TextView) findViewById(R.id.Bola3);
        TextView tvBola4 = (TextView) findViewById(R.id.Bola4);
        TextView tvBola5 = (TextView) findViewById(R.id.Bola5);
        TextView tvBola6 = (TextView) findViewById(R.id.Bola6);

        tvBola1.setText(Integer.toString(iChosen[0]));
        tvBola2.setText(Integer.toString(iChosen[1]));
        tvBola3.setText(Integer.toString(iChosen[2]));
        tvBola4.setText(Integer.toString(iChosen[3]));
        tvBola5.setText(Integer.toString(iChosen[4]));
        tvBola6.setText(Integer.toString(iChosen[5]));

        TextView tv =(TextView)findViewById(R.id.tvMostraResultado);
        String toDisplay = "";

        int[] iAcertos = new int[6];
        boolean bWin = false;

        for (int i = 0; i < Bilhete.mConcursos.size(); i++ )
        {
            byte[] toCompare = Bilhete.mConcursos.get(i).getGlobos();
            int iNumAcertos = 0;
            for (int j = 0; j < 6; j++)
            {
                if ( toCompare[0] == iChosen[j] || toCompare[1] == iChosen[j] || toCompare[2] == iChosen[j]
                ||   toCompare[3] == iChosen[j] || toCompare[4] == iChosen[j] || toCompare[5] == iChosen[j] )
                {
                    iAcertos[iNumAcertos] = iChosen[j];
                    iNumAcertos++;
                }
            }

            if ( 6 == iNumAcertos)
            {
                toDisplay += String.format("No concurso %d, em %2$te/%2$tm/%2$tY, saiu a sena!\n", + Bilhete.mConcursos.get(i).getNumConcurso(), Bilhete.mConcursos.get(i).getData() );
                if ( Bilhete.mConcursos.get(i).getGanhadoresSena() > 1 )
                {
                    toDisplay += String.format(Locale.GERMAN, "%d ganhadores. O rateio foi de R$%2$,.2f \n\n", Bilhete.mConcursos.get(i).getGanhadoresSena(), Bilhete.mConcursos.get(i).getPremioSena());
                }
                else
                {
                    toDisplay += String.format(Locale.GERMAN, "O único vencedor ganhou R$%,.2f \n\n", Bilhete.mConcursos.get(i).getPremioSena());
                }
                bWin = true;
            }
            else if ( 5 == iNumAcertos)
            {
                toDisplay += String.format("Em %2$te/%2$tm/%2$tY, saiu a quina: %3$d %4$d %5$d %6$d %7$d \n", Bilhete.mConcursos.get(i).getNumConcurso(), Bilhete.mConcursos.get(i).getData(), iAcertos[0], iAcertos[1], iAcertos[2], iAcertos[3], iAcertos[4] );
                if ( Bilhete.mConcursos.get(i).getGanhadoresQuina() > 1 )
                {
                    toDisplay += String.format(Locale.GERMAN, "%1$,d ganhadores. O rateio foi de R$%2$,.2f \n\n", Bilhete.mConcursos.get(i).getGanhadoresQuina(), Bilhete.mConcursos.get(i).getPremioQuina());
                }
                else
                {
                    toDisplay += String.format(Locale.GERMAN, "O único vencedor ganhou R$%,.2f \n\n", Bilhete.mConcursos.get(i).getPremioQuina());
                }
                bWin = true;
            }
            else if ( 4 == iNumAcertos)
            {
                toDisplay += String.format("Em %2$te/%2$tm/%2$tY, saiu a quadra: %3$d %4$d %5$d %6$d \n", Bilhete.mConcursos.get(i).getNumConcurso(), Bilhete.mConcursos.get(i).getData(), iAcertos[0], iAcertos[1], iAcertos[2], iAcertos[3] );
                if ( Bilhete.mConcursos.get(i).getGanhadoresQuadra() > 1 )
                {
                    toDisplay += String.format(Locale.GERMAN, "%1$,d ganhadores. O rateio foi de R$%2$,.2f \n\n", Bilhete.mConcursos.get(i).getGanhadoresQuadra(), Bilhete.mConcursos.get(i).getPremioQuadra());
                }
                else
                {
                    toDisplay += String.format(Locale.GERMAN, "O único vencedor ganhou R$%,.2f \n\n", Bilhete.mConcursos.get(i).getPremioQuina());
                }
                bWin = true;
            }
        }

        if ( bWin )
        {
            // http://soundbible.com/1003-Ta-Da.html
            MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.ta_da);
            mediaPlayer.start();
        }
        else
        {
            toDisplay += "Essa sequência nunca foi premiada!";
            MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.fail);
            mediaPlayer.start();
        }

        tv.setText(toDisplay);
    }
}
